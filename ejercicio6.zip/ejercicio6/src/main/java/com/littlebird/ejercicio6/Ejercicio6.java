/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.littlebird.ejercicio6;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio6 {//clase princiapl

    public static void main(String[] args) {
  
        Scanner scr = new Scanner(System.in);// se crea scanner para impesion en pantalla 

        System.out.print("Ingrese la temperatura en grados Celsius: ");// se solicita al user el ingreso de la temperatura 
        double celsius = scr.nextDouble();

        // Fórmula de conversión de Celsius a Fahrenheit: F = C * 9/5 + 32
        double fahrenheit = celsius * 9 / 5 + 32;

        System.out.println("La temperatura en grados Fahrenheit es: " + fahrenheit);// se imprime la conversion

    }
}
    

