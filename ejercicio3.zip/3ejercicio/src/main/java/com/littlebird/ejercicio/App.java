/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.littlebird.ejercicio;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class App {

    public static void main(String[] args) {// clase principal 
        System.out.println("EJERCICIO3");
        
        Scanner scr = new Scanner(System.in);// se crea scanner de impresion 

        System.out.print("Ingrese un número entero: ");// se solicita el ingreso al user 
        int numero = scr.nextInt(); // Leer el número ingresado por el usuario

        int contador = 0;// Variable contador para contar los dígitos

        if (numero == 0) {// condicional numero si o si igual a cero 
            contador = 1;// Si es cero, tiene un solo dígito
        } else {
            int numeroEntero = numero;// Variable para no modificar el numero ingresao 
            while (numeroEntero != 0) {// Calcular la cantidad de dígitos del número usando un bucle while
                numeroEntero /= 10;// Dividir el número por 10 para eliminar un dígito
                contador++; // Incrementar el contador de dígitos
            }
        }

        System.out.println("El número contiene " + contador + " dígitos.");// Mostrar el resultado en pantalla


    }
}


