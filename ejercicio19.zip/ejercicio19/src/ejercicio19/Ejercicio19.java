/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio19;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio19 {

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);// se crea scanner para impresion 

        System.out.print("Ingrese un número decimal: ");
        int decimal = scr.nextInt(); // Leer el número decimal

        String binario = convertirDecimalABinario(decimal); // Convertir a binario

        System.out.println("El número binario es: " + binario); // Mostrar el resultado en binario

    }

    public static String convertirDecimalABinario(int decimal) {
        StringBuilder binario = new StringBuilder(); // Usar StringBuilder para construir el número binario

        if (decimal == 0) {
            return "0"; // Caso especial: el decimal es 0
        }

        while (decimal > 0) {
            int residuo = decimal % 2; // Obtener el residuo de la división por 2
            binario.insert(0, residuo); // Agregar el residuo al inicio del binario
            decimal /= 2; // Dividir el decimal entre 2
        }

        return binario.toString(); // Devolver el número binario como cadena de caracteres
    }
}
