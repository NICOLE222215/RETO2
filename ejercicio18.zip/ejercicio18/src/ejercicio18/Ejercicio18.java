/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio18;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio18 {

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);// se crea scanner para impresion de texto por teclado 

        System.out.print("Ingrese un texto: ");
        String texto = scr.nextLine();// leer el texto 

        int vocales = 0;
        int consonantes = 0;

        for (char letra : texto.toCharArray()) { // Recorrer cada letra del texto
            if (letra >= 'a' && letra <= 'z') { // Verificar si la letra es una letra del alfabeto
                if (esVocal(letra)) {
                    vocales++; // Si es vocal, incrementar contador de vocales
                } else {
                    consonantes++; // Si no es vocal, incrementar contador de consonantes
                }
            }
        }

        // Mostrar resultados
        System.out.println("Cantidad de vocales: " + vocales);
        System.out.println("Cantidad de consonantes: " + consonantes);

    }

    // Función para verificar si una letra es vocal
    public static boolean esVocal(char letra) {
        return letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u';
    }
}
