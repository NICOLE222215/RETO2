/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.littlebird.ejercicio4;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio4 {

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);

        System.out.print("Ingrese un número: ");
        int numero = scr.nextInt();

        // condicional para verificar si el número es menor o igual a 1
        if (numero <= 1) {
            System.out.println(numero + " no es un número primo.");
        } else {
            boolean esPrimo = true;

            // ciclo for para verificar divisibilidad por números menores que el número ingresado
            for (int i = 2; i < numero; i++) {
                if (numero % i == 0) {
                    esPrimo = false;
                    break;
                }
            }

            if (esPrimo) {
                System.out.println(numero + " es un número primo.");
            } else {
                System.out.println(numero + " no es un número primo.");
            }
        }


    }
}