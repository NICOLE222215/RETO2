/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.littlebird.ejercicio9;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio9 {

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);// se crea sanner para imprimir datos ingresados por teclado 

        System.out.println("Ingrese 5 números:");// solicitar al usuario ingresar 5 numeros 
         // Leer cinco números ingresados por el usuario
        int numero1 = scr.nextInt();
        int numero2 = scr.nextInt();
        int numero3 = scr.nextInt();
        int numero4 = scr.nextInt();
        int numero5 = scr.nextInt();

        // Ordenar los números de forma ascendente (método simple)
        if (numero1 > numero2) {
            int temp = numero1;
            numero1 = numero2;
            numero2 = temp;
        }
        if (numero2 > numero3) {
            int temp = numero2;
            numero2 = numero3;
            numero3 = temp;
        }
        if (numero3 > numero4) {
            int temp = numero3;
            numero3 = numero4;
            numero4 = temp;
        }
        if (numero4 > numero5) {
            int temp = numero4;
            numero4 = numero5;
            numero5 = temp;
        }

        System.out.println("Números ordenados de forma ascendente: " +
                numero1 + " " + numero2 + " " + numero3 + " " + numero4 + " " + numero5);


    }
}
