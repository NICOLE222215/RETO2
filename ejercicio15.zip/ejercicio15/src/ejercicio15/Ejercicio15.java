/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio15;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio15 {


    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);

        System.out.print("Ingrese el radio del cilindro: ");// Solicitar al usuario que ingrese el radio del cilindro
        double radio = scr.nextDouble();

        System.out.print("Ingrese la altura del cilindro: ");// Solicitar al usuario que ingrese la altura del cilindro
        double altura = scr.nextDouble();

        double pi = 3.141592653589793; // Valor de pi

        double areaBase = pi * radio * radio;// Calcular el área de la base del cilindro
        double areaLateral = 2 * pi * radio * altura;// Calcular el área lateral del cilindro
        double areaTotal = 2 * areaBase + areaLateral; // Calcular el área total del cilindro
        double volumen = areaBase * altura;// Calcular el volumen del cilindro

        System.out.println("Area total del cilindro: " + areaTotal);// Mostrar el área total y el volumen del cilindro en pantalla

    }
}
