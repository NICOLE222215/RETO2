/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.littlebird.ejercicio5;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio5 {// clase principal

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);// se crea scanner de impresion en pantalla 

        System.out.print("Ingrese un número: ");
        int numero = scr.nextInt();

        long factorial = 1; // Inicializamos el factorial en 1 utilizando tipo de dato long para numeros grandes 

        for (int i = 1; i <= numero; i++) {
            factorial *= i; // Calculamos el factorial multiplicando por el número actual
        }

        System.out.println("El factorial de " + numero + " es: " + factorial);

    }
}