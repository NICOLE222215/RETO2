/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio16;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio16 {
    
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);

        System.out.print("Ingrese una contrasena: ");
        String contrasena = scr.nextLine();
        
        if (cumpleCondiciones(contrasena)) {
            System.out.println("Contraseña válida."); // Si cumple las condiciones, mostrar mensaje de válidación
        } else {
            System.out.println("Contraseña invalida."); // Si no cumple las condiciones, mostrar mensaje de no válida
        }


    }

    public static boolean cumpleCondiciones(String contrasena) {
        return contrasena.length() > 8 && contieneMayusculaOMinuscula(contrasena);
    }

    public static boolean contieneMayusculaOMinuscula(String contrasena) {
        return !contrasena.equals(contrasena.toLowerCase()) || !contrasena.equals(contrasena.toUpperCase());
    }
}
