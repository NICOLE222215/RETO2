/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio010;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio010 {

     public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);// se crea scanner 

        System.out.print("Ingrese el primer número: ");
        int numero1 = scr.nextInt(); // Leer el primer número

        System.out.print("Ingrese el segundo número: ");
        int numero2 = scr.nextInt(); // Leer el segundo número

        int mcd = calcularMCD(numero1, numero2); // Calcular el Máximo Común Divisor

        System.out.println("El máximo común divisor es: " + mcd); // Mostrar el resultado en pantalla
     }

    public static int calcularMCD(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b; // Calcular el residuo de la división entre a y b
            a = temp; // Asignar el valor de b a a y el residuo a b
        }
        return a; // Devolver el Máximo Común Divisor
    }
}
