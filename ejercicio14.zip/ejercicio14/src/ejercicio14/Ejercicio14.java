/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio14;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio14 {

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);// se crea el sacnner para imprmir lo ignresado por teclado 

        System.out.print("Ingrese un numero entero: ");
        int numero = scr.nextInt(); // Leer el número ingresado por el usuario

        int suma = 0; // Variable para almacenar la suma de los dígitos

        // Ciclo while para sumar los dígitos del número
        while (numero != 0) {
            suma += numero % 10; // Sumar el último dígito al resultado
            numero /= 10; // Eliminar el último dígito del número
        }

        // Mostrar la suma de los dígitos en pantalla
        System.out.println("La suma de los digitos es: " + suma);


    }
}
