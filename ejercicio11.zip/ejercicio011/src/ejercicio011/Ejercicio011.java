/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio011;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio011 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese un numero : ");
        int n = sc.nextInt(); // Leer el número N ingresado por el usuario

        System.out.println("Los primeros " + n + " terminos de la serie Fibonacci son:");
        for (int i = 0; i < n; i++) { // Ciclo para calcular e imprimir los términos de la serie
            int fibonacciTerm = calcularFibonacci(i); // Calcular el término de Fibonacci
            System.out.print(fibonacciTerm + " "); // Mostrar el término en pantalla
        }
    }

    public static int calcularFibonacci(int n) {
        if (n <= 1) {
            return n; // Casos base: para n=0 retorna 0, para n=1 retorna 1
        }
        return calcularFibonacci(n - 1) + calcularFibonacci(n - 2); // Calcular término n de Fibonacci de manera recursiva
    }
}
