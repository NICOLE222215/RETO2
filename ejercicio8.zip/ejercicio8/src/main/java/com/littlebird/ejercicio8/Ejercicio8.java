/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.littlebird.ejercicio8;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio8 {

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);

        System.out.print("Ingrese un número: ");
        int n = scr.nextInt();

        System.out.println("Los primeros números primos hasta " + n + " son:");
        int contador = 0;// Contador de números primos encontrados
        int numero = 2; // Número a verificar como primo

        while (contador < n) {// Bucle para encontrar y mostrar los primeros n números primos
            if (esPrimo(numero)) {// Si el número es primo
                System.out.print(numero + " ");
                contador++;// Incrementar el contador de números primos encontrados
            }
            numero++;
        }

   
    }

    // Función para verificar si un número es primo
    public static boolean esPrimo(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}





