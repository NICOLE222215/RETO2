/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.littlebird.ejercicio10;

import java.util.Scanner;

/**
 *
 * @author nicol
 */
public class Ejercicio10 {


    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);

        System.out.print("Ingrese la base: ");
        double base = scr.nextDouble(); // Leer la base ingresada por el usuario

        System.out.print("Ingrese el exponente: ");
        int exponente = scr.nextInt(); // Leer el exponente ingresado por el usuario

        double potencia = 1.0; // Variable para almacenar el resultado de la potencia

        // Calcular la potencia
        if (exponente >= 0) { // Si el exponente es no negativo
            for (int i = 0; i < exponente; i++) {
                potencia *= base; // Multiplicar la base por sí misma exponente veces
            }
        } else { // Si el exponente es negativo
            for (int i = 0; i > exponente; i--) {
                potencia /= base; // Dividir 1 por la base exponente veces
            }
        }

        // Mostrar el resultado de la potencia en pantalla
        System.out.println("La potencia de " + base + " elevado a " + exponente + " es: " + potencia);

    }
}



 
